import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import sqlite3

"""
program: book tracker update 3.py
Author: Belinda M.
Date: 02/15/2025
The Book Tracker program helps you manage your book collection by allowing you to add, edit, delete, and search for books.
It ensures each book title is unique, preventing duplicate entries.
This tool is perfect for keeping track of all the books you own or want to read,
making your collection organized and easily accessible.
"""

# Initialize the main application window
class BookTrackerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Book Tracker")
        self.create_widgets()
        self.setup_database()
        self.load_books()

    def create_widgets(self):
        # Create main window widgets
        self.title_label = tk.Label(self.root, text="Book Tracker", font=("Helvetica", 16))
        self.title_label.pack(pady=10)

        self.search_label = tk.Label(self.root, text="Search:")
        self.search_label.pack(pady=5)
        self.search_entry = tk.Entry(self.root)
        self.search_entry.pack(pady=5)
        self.search_entry.bind("<KeyRelease>", self.search_books)

        self.add_button = tk.Button(self.root, text="Add Book", command=self.open_add_book_window)
        self.add_button.pack(pady=5)

        self.edit_button = tk.Button(self.root, text="Edit Book", command=self.open_edit_book_window)
        self.edit_button.pack(pady=5)

        self.delete_button = tk.Button(self.root, text="Delete Book", command=self.delete_book)
        self.delete_button.pack(pady=5)

        self.book_listbox = tk.Listbox(self.root)
        self.book_listbox.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)

    def open_add_book_window(self):
        # Create a new window for adding a book
        self.add_book_window = tk.Toplevel(self.root)
        self.add_book_window.title("Add Book")

        self.title_entry_label = tk.Label(self.add_book_window, text="Title:")
        self.title_entry_label.pack(pady=5)
        self.title_entry = tk.Entry(self.add_book_window)
        self.title_entry.pack(pady=5)

        self.author_entry_label = tk.Label(self.add_book_window, text="Author:")
        self.author_entry_label.pack(pady=5)
        self.author_entry = tk.Entry(self.add_book_window)
        self.author_entry.pack(pady=5)

        self.save_button = tk.Button(self.add_book_window, text="Save", command=self.save_book)
        self.save_button.pack(pady=10)

    def open_edit_book_window(self):
        # Create a new window for editing a book
        selected_book = self.book_listbox.curselection()
        if not selected_book:
            messagebox.showerror("Error", "Please select a book to edit")
            return

        self.edit_book_window = tk.Toplevel(self.root)
        self.edit_book_window.title("Edit Book")

        self.title_entry_label = tk.Label(self.edit_book_window, text="Title:")
        self.title_entry_label.pack(pady=5)
        self.title_entry = tk.Entry(self.edit_book_window)
        self.title_entry.pack(pady=5)

        self.author_entry_label = tk.Label(self.edit_book_window, text="Author:")
        self.author_entry_label.pack(pady=5)
        self.author_entry = tk.Entry(self.edit_book_window)
        self.author_entry.pack(pady=5)

        book_details = self.book_listbox.get(selected_book).split(" by ")
        self.title_entry.insert(0, book_details[0])
        self.author_entry.insert(0, book_details[1])

        self.save_button = tk.Button(self.edit_book_window, text="Save", command=self.save_edited_book)
        self.save_button.pack(pady=10)

    def save_edited_book(self):
        # Save the edited book details to the database
        selected_book = self.book_listbox.curselection()
        if not selected_book:
            messagebox.showerror("Error", "Please select a book to edit")
            return

        title = self.title_entry.get()
        author = self.author_entry.get()
        if title or author:
            book_details = self.book_listbox.get(selected_book).split(" by ")
            book_id = self.get_book_id(book_details[0], book_details[1])
            if title:
                self.cursor.execute('UPDATE books SET title = ? WHERE id = ?', (title, book_id))
            if author:
                self.cursor.execute('UPDATE books SET author = ? WHERE id = ?', (author, book_id))
            self.conn.commit()
            self.book_listbox.delete(selected_book)
            self.book_listbox.insert(selected_book, f"{title or book_details[0]} by {author or book_details[1]}")
            messagebox.showinfo("Success", "Book updated successfully")
            self.edit_book_window.destroy()
        else:
            messagebox.showerror("Error", "Please enter either title or author")

    def delete_book(self):
        # Delete the selected book from the database
        selected_book = self.book_listbox.curselection()
        if not selected_book:
            messagebox.showerror("Error", "Please select a book to delete")
            return

        book_details = self.book_listbox.get(selected_book).split(" by ")
        self.cursor.execute('DELETE FROM books WHERE title = ? AND author = ?', (book_details[0], book_details[1]))
        self.conn.commit()
        self.book_listbox.delete(selected_book)
        messagebox.showinfo("Success", "Book deleted successfully")

    def search_books(self, event):
        # Search for books in the listbox
        search_query = self.search_entry.get().lower()
        self.book_listbox.delete(0, tk.END)
        self.cursor.execute('SELECT title, author FROM books')
        for row in self.cursor.fetchall():
            if search_query in row[0].lower() or search_query in row[1].lower():
                self.book_listbox.insert(tk.END, f"{row[0]} by {row[1]}")

    def setup_database(self):
        # Connect to the SQLite database
        self.conn = sqlite3.connect('books.db')
        self.cursor = self.conn.cursor()
        # Create the books table if it doesn't exist
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                author TEXT NOT NULL
            )
        ''')
        self.conn.commit()

    def save_book(self):
        # Save the book details to the database
        title = self.title_entry.get()
        author = self.author_entry.get()
        if title and author:
            self.cursor.execute('INSERT INTO books (title, author) VALUES (?, ?)', (title, author))
            self.conn.commit()
            self.book_listbox.insert(tk.END, f"{title} by {author}")
            messagebox.showinfo("Success", "Book added successfully")
            self.add_book_window.destroy()
        else:
            messagebox.showerror("Error", "Please enter both title and author")

    def load_books(self):
        # Load books from the database
        self.cursor.execute('SELECT title, author FROM books')
        for row in self.cursor.fetchall():
            self.book_listbox.insert(tk.END, f"{row[0]} by {row[1]}")

    def get_book_id(self, title, author):
        # Get the book ID based on title and author
        self.cursor.execute('SELECT id FROM books WHERE title = ? AND author = ?', (title, author))
        return self.cursor.fetchone()[0]

# Main function to run the application
if __name__ == "__main__":
    root = tk.Tk()
    app = BookTrackerApp(root)
    root.mainloop()